					Assignment 4
Name: Aditya Das

UTA ID: 1001675762

How to compile : python maxconnect4.py interactive [input_file] [computer-next/human-next] [depth]
		 or
		 python	maxconnect4.py one-move [input_file] [output_file] [depth]
 
Language used : python

Appropriate comments have been given in the code

Code Structure: Two files ; MaxConnect4Game.py and maxconnect4.py  

File1:   MaxConnect4Game.py

Function Name: checkPieceCount 
Function Description:  checks the number of pieces present in the current board


Function Name: printGameBoard  
Function Description: prints the current state of the board

Function Name: printGameBoardtoFile 
Function Description: writes the current state of the board to the appropriate file

Function Name: playPiece 
Function Description: places the piece at the selected column.

Function Name: countScore 
Function Description: counts the current score of the board


File2:   maxconnect4.py

Function Name: viable 
Function Description: checks for all viable columns

Function Name: possible  
Function Description:  checks if any of the viable/available columns get the player a score, assigns a depth value and starts filling up the positions to check where it gets a point

class minimax - implements the minimax algorithm

Function Name: Deci 
Function Description: decides which position the AI will play the game

Function Name: minim  
Function Description: minimiser function

Function Name: maxM 
Function Description: maximiser function

Function Name: eval 
Function Description: evaluation function

Function Name: mover 
Function Description: after one play, it prints the board and writes the boards state to the file

Function Name: interactiveGame 
Function Description: inputs the selected column in interactive mode, and if it is the computer's turn to play it uses the minimax class to select the play

Function Name: declarewinner 
Function Description: declares the winner after the match is over


Depth vs Time

1	0.300s
2       0.425s
3	0.564s
4	0.580s
5       0.637s
10	0.830s
15	1.150s	
20	1.286s
30 	1.577s
40	1.568s
50	1.585s
100	1.619s
