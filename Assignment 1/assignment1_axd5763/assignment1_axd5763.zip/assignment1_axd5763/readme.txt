Name:- Aditya Das

NetID:- axd5763

MAV ID:- 1001675762

Programming language used:- Python
 
How to run:- python find_route.py uninf file1.txt Source_City Destination_City
Informed search has not been implemented yet. Giving the heuristic file or extra arguments will throw an error.
The file will not run if improper input is given( 5 arguments but uninf is not properly specified or if the number of arguments is different than 5)

Code structure:- 
Due to unavailabilty of Priority Queue library in Python 2.4.3. Had to implement my own rendition of a priority Queue.

Class Graph Stores 3 things
edges stores the neighbours of all the cities in a dictionary(key= city name, value = neighbours)
weights stores the edge/distance weight of all the cities neighbours( key = city name, value = neighbour edge weight)
path stores the path visited. Was used for debugging. Not really used in the program

class ModelData
reads the file and stores all the data in a list.

Class Uninformed
"get_edges" function gets the neighbours for the dictionary edges in class Graph
"something" function  implements the Uniform Cost search Algorithm and prints the route

"trackback" function implements the backtracking from destination node to source node and sends the data to "something" function
 
